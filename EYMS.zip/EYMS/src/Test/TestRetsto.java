package Test;

import Restaurant.Restaurant;

public class TestRetsto {
	
	public static void main(String [] args){
		Restaurant res1=new Restaurant("CHEZ LILY");
		System.out.println(res1);
	}
}
