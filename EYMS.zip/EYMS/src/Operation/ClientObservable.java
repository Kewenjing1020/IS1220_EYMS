package Operation;

public interface ClientObservable {

	public abstract void notifyAd();
	
	public abstract void notifyBirthday();
}
