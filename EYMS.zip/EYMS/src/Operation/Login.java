package Operation;

import User.User;

public interface Login{

	public void login(User user);
}
