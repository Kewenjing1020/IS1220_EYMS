package Operation;

public interface Register {

	public void register(String first_name, String last_name, String user_name, String password);
}
