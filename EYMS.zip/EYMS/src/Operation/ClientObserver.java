package Operation;

import java.util.ArrayList;

public interface ClientObserver {
	
	public abstract void update(ArrayList<String> ads);
}
