package User;

public class Personnel extends User implements Runnable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6014730461542734062L;

	public Personnel(String username, String password) {
		super(username, password);
		// TODO Auto-generated constructor stub
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
