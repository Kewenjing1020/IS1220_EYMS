package Restaurant;

public class MealNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MealNotFoundException() {
		// TODO Auto-generated constructor stub
		System.out.println("this meal doesn't in the meal list");
	}
}
